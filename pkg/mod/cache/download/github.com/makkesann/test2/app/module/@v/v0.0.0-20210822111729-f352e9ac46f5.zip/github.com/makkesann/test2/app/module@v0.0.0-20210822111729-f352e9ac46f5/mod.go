package module

func Goodbye() string {
	return "Goodbye"
}
