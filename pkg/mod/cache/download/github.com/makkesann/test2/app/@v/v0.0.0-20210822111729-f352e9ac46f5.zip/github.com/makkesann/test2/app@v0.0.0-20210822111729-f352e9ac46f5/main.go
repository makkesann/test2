package main

import (
	"fmt"

	"github.com/makkesann/test2/app/module"
)

func main() {
	fmt.Println(module.Goodbye())
}
